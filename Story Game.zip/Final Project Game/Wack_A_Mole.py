import pythonGraph
import pygame
import random
from time import time
width = 900
height = 600

pythonGraph.open_window(width, height)
pygame.init()

def displayTitle():
    pythonGraph.draw_image("Wack_A_Mole.png", 0, 0, 900, 600)
    z = 0
    while z == 0:
        pythonGraph.update_window()
        button = pygame.mouse.get_pressed(3)
        mouse = pygame.mouse.get_pos()
        if 100 <= mouse[0] <= 800 and 100 <= mouse[1] <= 500 and button[0] == True:
            pythonGraph.draw_image("wack_a_m_back.png", 0, 0, 900, 600)
            pythonGraph.draw_text('Click on the avatars to hit the students', 150, 275, 'BLACK', 50)
            pythonGraph.update_window()
            z = 1

def startGame():
    start = False
    while start == False:
        button = pygame.mouse.get_pressed(3)
        if button[0] == True:
            start = True
            pythonGraph.draw_image("wack_a_m_back.png", 0, 0, 900, 600)
            

def displayStudent(width, height):
    x_coord = random.randint(100, 800)
    y_coord = random.randint(100, 500)
    number = random.randint(1,4)
    if number == 1:
        pythonGraph.draw_image('Stephen_mole.png', x_coord, y_coord, 100, 100)
    elif number == 2:
        pythonGraph.draw_image('Stecy_mole.png', x_coord, y_coord, 100, 100)
    elif number == 3:
        pythonGraph.draw_image('Maggie_mole.png', x_coord, y_coord, 100, 100)
    else:
        pythonGraph.draw_image('filip_mole.png', x_coord, y_coord, 100, 100)
    z = 0
    while z == 0:
        pythonGraph.update_window()
        button = pygame.mouse.get_pressed(3)
        mouse = pygame.mouse.get_pos()
        if x_coord <= mouse[0] <= x_coord + 100 and y_coord <= mouse[1] <= y_coord + 100 and button[0] == True:
            pythonGraph.draw_image("wack_a_m_back.png", 0, 0, 900, 600)
            pythonGraph.update_window()
            z = 1
    

displayTitle()
time_delay = time()
current_time = time()
while current_time <= time_delay + 3:
    current_time = time()
startGame()
start_time = time()
current_time = time()
count = 0
while current_time <= start_time + 15:
    current_time = time()
    displayStudent(width,height)
    count = count + 1
count = str(count)
pythonGraph.draw_text('You hit '+count+' students!', 215, 275, 'BLACK', 75)
pythonGraph.wait_for_close()
