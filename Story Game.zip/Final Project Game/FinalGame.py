from storyCode import FratStory, GraduationStory
from pythonGraph import *
import pygame

width = 900
height = 600

pythonGraph.open_window(width, height)
pygame.init()

pythonGraph.clear_window("WHITE")
pythonGraph.draw_image("Start_Screen.PNG", 0, 0, 900, 600)

z = 0
while z == 0:
    pythonGraph.update_window()
    button = pygame.mouse.get_pressed(3)
    mouse = pygame.mouse.get_pos()
    if 260 <= mouse[0] <= 635 and 425 <= mouse[1] <= 520 and button[0]:
        pythonGraph.draw_image("Grad_sim_title.PNG", 0, 0, 450, 600)
        pythonGraph.draw_image("Frat_sim_title.PNG", 450, 0, 450, 600)
        z = 1

while z == 1:
    pythonGraph.update_window()
    button = pygame.mouse.get_pressed(3)
    mouse = pygame.mouse.get_pos()
    if 570 <= mouse[0] <= 775 and 385 <= mouse[1] <= 460 and button[0]:
        # Run frat story
        pygame.display.quit()
        frat_story = FratStory()
        frat_story.play()
        z = 2
    elif 135 <= mouse[0] <= 335 and 380 <= mouse[1] <= 450 and button[0]:
        # Run graduation story
        pygame.display.quit()
        graduation_story = GraduationStory()
        graduation_story.play()
        z = 2


