
import pygame

class FratStory:

    def __init__(self):
        pass

    def get_choice(self, prompt, choices):
        print(prompt)
        for i, choice in enumerate(choices):
            print(f"{i + 1}. {choice}")

        while True:
            try:
                choice_num = int(input("Enter the number of your choice: "))
                if 1 <= choice_num <= len(choices):
                    return choices[choice_num - 1]
                else:
                    print("Invalid choice. Please enter a valid number.")
            except ValueError:
                print("Invalid input. Please enter a number.")

    def play(self):
        current_choice = None
        
        answer = self.get_choice("You are outside of the K-Sig Fraternity. Would you like to go in through the back door or the front door?", ["back door", "front door"])

        while True:
            if answer == "front door":
                answer = self.get_choice("Congrats! You made it inside the party. Would you like to go dance or get a cup of jungle juice?", ["dance", "jungle juice"])

                if answer == "dance":
                    answer = self.get_choice("Congrats! You made it onto the dance floor and have moves so killer that a K-Sig brother challenges you to a dance-off! Do you accept?", ["yes", "no"])

                    if answer == "yes":
                        answer = self.get_choice("You have accepted the dance-off! Would you like to twerk or do the robot?", ["twerk", "robot"])

                        if answer == "robot":
                            print("Everyone loves your robot! You win the dance-off and crowdsurf away! You decide that it's time to go home... but can you find your way?")
                            import GetHomeGame
                            
                        elif answer == "twerk":
                            print("Oh no! You forgot that you don't actually know how to twerk. You lose the dance-off and leave the party.")
                            restart = input("Would you like to restart the game? (yes/no) ")
                            if restart.lower().strip() == "yes":
                                self.reset()
                            else:
                                break
                    elif answer == "no":
                        print("Oh no! Everyone thinks you're lame for not accepting :/. You leave the party.")
                        restart = input("Would you like to restart the game? (yes/no) ")
                        if restart.lower().strip() == "yes":
                            self.reset()
                        else:
                            break
                elif answer == "jungle juice":
                    print("Oh no! Drinking the jungle juice is never a good choice! You get sick and have to leave the party.")
                    restart = input("Would you like to restart the game? (yes/no) ")
                    if restart.lower().strip() == "yes":
                        self.reset()
                    else:
                        break
            elif answer == "back door":
                print("Oh no! You get to the backdoor and realize that you forgot your ID. The brothers of K-Sig do not let you into the party.")
                restart = input("Would you like to restart the game? (yes/no) ")
                if restart.lower().strip() == "yes":
                    self.reset()
                else:
                    break

    def reset(self):
        self.play()


class GraduationStory:

    def __init__(self):
        pass

    def get_choice(self, prompt, choices):
        print(prompt)
        for i, choice in enumerate(choices):
            print(f"{i + 1}. {choice}")

        while True:
            try:
                choice_num = int(input("Enter the number of your choice: "))
                if 1 <= choice_num <= len(choices):
                    return choices[choice_num - 1]
                else:
                    print("Invalid choice. Please enter a valid number.")
            except ValueError:
                print("Invalid input. Please enter a number.")

    def play(self):
        while True:
            answer = self.get_choice("You are an administrator at CC in charge of choosing this year's graduation speaker! You have a list of notable people you could ask. Do you ask one of the people on this list, or do you ask Liz Cheney?", ["Liz Cheney", "someone else"])

            if answer == "Liz Cheney":
                answer = self.get_choice("You ask Liz Cheney and she accepts. The seniors, however, are not excited about this. You receive a petition signed by 300 seniors. Do you double down or disinvite Liz Cheney?", ["double down", "disinvite"])

                if answer == "double down":
                    print("Congrats! You have made your seniors angrier and are not adhering to your publicized values. You choose to double down again... let's see if you can successfully crush the complaints of your seniors.")
                    import Wack_A_Mole
                    answer = self.get_choice("It is getting close to graduation. You hear that the seniors are planning a protest. Do you send out an email to address these rumors or do you let it be?", ["let it be", "send an email"])

                    if answer == "send an email":
                        answer = self.get_choice("You send an email to the seniors of CC about 'Freedom of Expression' and threaten to hold their diplomas if they protest. Unfortunately, this email is ineffective and there is a protest at graduation. Do you hold their diplomas or do you let it be?", ["hold their diplomas", "let it be"])

                        if answer == "hold their diplomas":
                            answer = input("Congrats! It is now 2030, and the majority of seniors who graduated in 2023 have low-paying jobs. This seriously affects your 'post-graduation' statistics, but at least you still get funding from the Cheney family!")
                            #end of game

                        elif answer == "let it be":
                            print("The protest continues uninterrupted. Liz Cheney is upset that you did nothing to stop the protest & you lose the Cheney family's funding.")
                            restart = input("Would you like to restart the game? (yes/no) ")
                            if restart.lower().strip() == "yes":
                                continue
                            else:
                                break

                        else:
                            print("Not a valid answer! You must restart the game.")
                            restart = input("Would you like to restart the game? (yes/no) ")
                            if restart.lower().strip() == "yes":
                                continue
                            else:
                                break

                    elif answer == "let it be":
                        print("There is a huge protest at graduation. Liz Cheney is upset and you lose the Cheney family's funding.")
                        restart = input("Would you like to restart the game? (yes/no) ")
                        if restart.lower().strip() == "yes":
                            continue
                        else:
                            break

                    else:
                        print("Not a valid answer! You must restart the game.")
                        restart = input("Would you like to restart the game? (yes/no) ")
                        if restart.lower().strip() == "yes":
                            continue
                        else:
                            break

                elif answer == "disinvite":
                    print("You disinvite Liz Cheney. The seniors are happy and the class of 2023 gets an even more notable speaker!")
                    restart = input("Would you like to restart the game? (yes/no) ")
                    if restart.lower().strip() == "yes":
                        continue
                    else:
                        break

                else:
                    print("Not a valid answer! You must restart the game.")
                    restart = input("Would you like to restart the game? (yes/no) ")
                    if restart.lower().strip() == "yes":
                        continue
                    else:
                        break

            elif answer == "someone else":
                print("You choose someone else as the graduation speaker. The seniors are happy with the choice!")
                restart = input("Would you like to restart the game? (yes/no) ")
                if restart.lower().strip() == "yes":
                    continue
                else:
                    break

            else:
                print("Not a valid answer! You must restart the game.")
                restart = input("Would you like to restart the game? (yes/no) ")
                if restart.lower().strip() == "yes":
                    continue
                else:
                    break

    def reset(self):
        self.play()


def main():
    pygame.init()
    pygame.display.set_caption("Frat Game")

    frat_game = FratStory()
    grad_game = GraduationStory()

    while True:
        game_choice = input("Choose a game to play: Frat Story (F) or Graduation Story (G) (Q to quit): ")

        if game_choice.lower().strip() == "f":
            frat_game.reset()
        elif game_choice.lower().strip() == "g":
            grad_game.reset()
        elif game_choice.lower().strip() == "q":
            break
        else:
            print("Invalid choice. Please enter F, G, or Q.")

    pygame.quit()

if __name__ == "__main__":
    main()
