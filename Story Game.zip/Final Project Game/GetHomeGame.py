
#add house
#end game
#add curves
import pygame
import pythonGraph
from time import time

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)

# Pygame setup
pygame.init()
screen = pygame.display.set_mode((900, 600))
clock = pygame.time.Clock()
running = True
dt = 0

background_image = pygame.image.load("image.png")
avatar_image = pygame.image.load("frat.png").convert()
avatar_image = pygame.transform.scale(avatar_image, (30, 30))

house = pygame.image.load("house.png").convert()
house = pygame.transform.scale(house, (50, 50))


player_pos = [150, 70]
player_speed = 8

path_points = [
    (150, 70),
    (170, 70),
    (190, 70),
    (220, 70),
    (240, 70),
    (260, 70),
    (260, 90),
    (260, 100),
    (260, 110),
    (260, 120),
    (260, 130),
    (260, 140),
    (260, 150),
    (280, 150),
    (295, 150),
    (310, 150),
    (325, 150),
    (350, 150),
    (370, 150),
    (390, 150),
    (400, 150),
    (420, 150),
    (440, 150),
    (460, 150),
    (480, 150),
    (500, 150),
    (520, 150),
    (530, 150),
    (550, 150),
    (565, 150),
    (580, 150),
    (580, 170),
    (580, 190),
    (580, 210),
    (580, 230),
    (580, 250),
    (580, 270),
    (580, 290),
    (580, 310),
    (580, 330),
    (580, 350),
    (580, 370),
    (580, 390),
    (580, 410),
    (580, 430),
    (580, 450),
    (600, 450),
    (620, 450),
    (640, 450),
    (660, 450),
    (680, 450),
    (700, 450)
]

finish_line = (700, 450)  # Coordinates of the finish linemake it end when user gets here
finish_vicinity = pygame.Rect (abs(finish_line[0] - 20), abs(finish_line[1] - 25), 30, 30)

def draw_path():
    pygame.draw.lines(screen, RED, False, path_points, 40)

def is_outside_path():
    x, y = player_pos
    for point in path_points:
        if abs(x - point[0]) < 20 and abs(y - point[1]) < 20:
            return False
    return True

def is_in_finish():
    x, y = player_pos
    if finish_vicinity.collidepoint(x, y):
        return True
    return False

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_UP]:
        player_pos[1] -= player_speed
    if keys[pygame.K_DOWN]:
        player_pos[1] += player_speed
    if keys[pygame.K_LEFT]:
        player_pos[0] -= player_speed
    if keys[pygame.K_RIGHT]:
        player_pos[0] += player_speed
        
    screen.blit(background_image, (-350, -20))
    draw_path()
    screen.blit(avatar_image, (player_pos[0] - avatar_image.get_width() // 2, player_pos[1] - avatar_image.get_height() // 2))
    screen.blit(house, (700, 430))

    if is_outside_path():
        running = False
        font = pygame.font.SysFont("Sans", 36)
        txtsurf = font.render("You pregamed a little too much I guess, try again!", True, RED)
        screen.blit(txtsurf,(350 - txtsurf.get_width() // 2.5, 500 - txtsurf.get_height() // 2)) 

    if is_in_finish():
        running = False
        print("Good joooob!")
        font = pygame.font.SysFont("Sans", 36)
        txtsurf = font.render("You've arrived, your homies are waiting for you!", True, RED)
        screen.blit(txtsurf,(350 - txtsurf.get_width() // 2.5, 500 - txtsurf.get_height() // 2))   

    pygame.display.flip()


time_delay = time()
current_time = time()
while current_time <= time_delay + 4:
    current_time = time()
pygame.quit()
