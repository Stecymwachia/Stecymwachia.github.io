#!/usr/bin/env python3
#name: stecy mwachia
#date: 05.01.23
#project: Tip Calculator

#input customer satisfaction
print("rate your experience at our resteraunt from a scale of 1-3")
csat = int(input('enter costumer satisfaction (1 = bad, 2 = ok, 3 = good)'))
total = float(input('enter total'))
if csat == 3:
    tip_n = .20
if csat == 2:
    tip_n = .15
if csat == 1:
    tip_n = .10
    
tipamount = (total * tip_n)                       
# REPORT SATISFACTION & TIP
print("satisfaction:")
print(csat)
print("Your tip should be:")
print(tipamount)
