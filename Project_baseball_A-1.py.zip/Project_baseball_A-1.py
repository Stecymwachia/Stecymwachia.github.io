#!/usr/bin/env python3
#name: stecy mwachia
#date: 05.14.23
#project: Project_baseball_A-1
    
def getFile():
    # Collect the file names from user
    file_name = input("Enter file: ")
    return file_name

def get_data(filename):
    team_list = []
    with open(filename, "r") as in_file:
        for line in in_file:
            # Split the line into parts using commas
            parts = line.strip().split(",")

            # Extract the team name and division
            name, division = parts[:2]

            # Extract the number of games won and lost
            games_won, games_lost = map(int, parts[2:])

            # Add the team to the list
            team = {"name": name, "division": division, "games_won": games_won, "games_lost": games_lost}
            team_list.append(team)

    return team_list

def splitLeague(input_name):
    # Initialize the division lists
    east_teams = []
    central_teams = []
    west_teams = []

    # Read the team data from the input file and split it into division lists
    with open(input_name, "r") as in_file:
        for line in in_file:
            parts = line.strip().split(",")
            division = parts[1]
            team = {"name": parts[0], "wins": int(parts[2]), "losses": int(parts[3])}
            if division == "East":
                east_teams.append(team)
            elif division == "Central":
                central_teams.append(team)
            elif division == "West":
                west_teams.append(team)

    # Display the division lists
    displayTeams("East", east_teams)
    displayTeams("Central", central_teams)
    displayTeams("West", west_teams)

def displayTeams(division, teams):
    print(division)
    displayHeader()
    for team in teams:
        name = team["name"]
        wins = team["wins"]
        losses = team["losses"]
        win_percent = wins / (wins + losses) * 100
        displayData(name, wins, losses, win_percent)
    print()


def displayTeam(input_name):
    team_data = {}
    team_list = get_data(input_name)
    for team in team_list:
        name = team["name"]
        division = team["division"]
        games_won = team["games_won"]
        games_lost = team["games_lost"]

        # If we haven't seen this team, add them to the dictionary
        if name not in team_data:
            team_data[name] = []

        # Add the games won and lost to the team's data
        team_data[name].append(games_won)
        team_data[name].append(games_lost)

    # Call displayHeader to print the header.
    displayHeader()

    # Calculate the percentage of games won
    for name, team in team_data.items():
        total_games = team[0] + team[1]
        games_won = team[0]
        games_lost = team[1]
        win_percent = games_won / total_games * 100


 # Call displayData to print the team name, games won, games lost, and percentage of games won.
        displayData(name, games_won, games_lost, win_percent)
def displayTeam(name, total_sales):
        # receives the divison team list
        # then prints them as formatted output.
        formatted_data = "{:<20}{:<10.2f}".format(name, total_sales)
        print(formatted_data)
    
def displayHeader():
    print("{:<25}{:<12}{:<6}{:<6}{:<11}".format("Team", "Division", "Wins", "Losses", "Win %"))
    print("{:<25}{:<12}{:<6}{:<6}{:<11}".format("-" * 25, "-" * 12, "-" * 6, "-" * 6, "-" * 11))


   
def main():
    input_file = getFile()
    splitLeague(input_file)

  
if __name__ == "__main__":
    main()
