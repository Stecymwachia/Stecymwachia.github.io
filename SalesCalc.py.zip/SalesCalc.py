#!/usr/bin/env python3
#name: stecy mwachia
#date: 05.11.23
#project: SalesCalc
    
def getFileName():
    # Collect the file names from user
    file_name = input("Enter file: ")
    return file_name

def openReadFile(input_name):
    sales_data = {}
    with open(input_name, "r") as in_file:
        for line in in_file:
            # Split the line into parts using whitespace
            parts = line.split( )

            # Extract the salesperson's name
            name = " ".join(parts[:2])

            # Extract the sales amount
            sales = int(parts[-1])

            # If we haven't seen this salesperson before, add them to the dictionary
            if name not in sales_data:
                sales_data[name] = []

            # Add the sales amount to the salesperson's data
            sales_data[name].append(sales)
            
    # Call displayHeader to print the header.
        displayHeader()

    # Calculate the total sales for each salesperson and print the results
    for name, sales in sales_data.items():
        total_sales = sum(sales)

        # Call displayData to print the salesperson's name and total sales.
        displayData(name, total_sales)

def displayHeader():
    print("{:<20}{:<10}".format("SalesPerson", "Total_sales"))
    print("{:<20}{:<10}".format("-" * 15, "-" * 12))

def displayData(name, total_sales):
    # receives two parameters, the Sales persons's name and total sales,
    # then prints them as formatted output.
    formatted_data = "{:<20}{:<10.2f}".format(name, total_sales)
    print(formatted_data)
   
def main():
    input_file = getFileName()
    openReadFile(input_file)
  
if __name__ == "__main__":
    main()
