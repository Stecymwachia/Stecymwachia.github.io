#!/usr/bin/env python3
#name: stecy mwachia
#date: 05.01.23
#project: Organism Growth Prediction
flag = True

#input initial number of organisms
n_oo= int(input("Enter Initial Number of Organisms:"))    
#input the rate of growth
r_og= int(input("Enter Rate of Growth:")) 
#input the number of hours it takes to achieve rate
while flag:
    n_o_h = int(input("Enter Number of Hours it Takes to Achieve Rate:"))
    if n_o_h < 0:
        flag = False
        print("Negative growth rates are not allowed")
        continue
    if n_o_h > 0:
        flag = True
        break
Tot=float(int(n_oo * ((1+r_og) ** n_o_h)))
TotPop=float(int(round(Tot , 0)))
print("The population will be", TotPop, "at", n_o_h, "hours" )

#input number of hours for population growth

# "Negative growth rates are not allowed"

