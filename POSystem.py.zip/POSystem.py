#!/usr/bin/env python3
# name: stecy mwachia
# date: 05.02.23
# project: POSystem.py

# declareGlobals here

# pizza, 5.95
p = 5.95
# fries, 3.95
f = 3.95
# drinks, 2.75
d = 2.75
#tax
tax_rate = 0.085

def getQuantity(item_name):
    while True:
        try:
            quantity = int(input(f"How many {item_name} do you want? "))
            if quantity < 0:
                print("Please enter a positive quantity.")
            else:
                return quantity
        except ValueError:
            print("Please enter a valid integer.")


def printBill(qtPizza, qtFries, qtDrinks, tax_rate):
    # Calculate the subtotal and tax
    subtotal = p * qtPizza + f * qtFries + d * qtDrinks
    tax = subtotal * tax_rate

    # Calculate the total bill
    total = subtotal + tax

    # Format and print the bill
    print("ITEM\t\tQUANTITY\tPRICE")
    print("Pizza slices\t{}\t\t${:.2f}".format(qtPizza, p))
    print("Fries\t\t{}\t\t${:.2f}".format(qtFries, f))
    print("Drinks\t\t{}\t\t${:.2f}".format(qtDrinks, d))
    print("Subtotal\t\t\t${:.2f}".format(subtotal))
    print("Tax ({}%)\t\t\t${:.2f}".format(tax_rate*100, tax))
    print("Total\t\t\t${:.2f}".format(total))


def printError(errorMsg):
    print("Error: " + errorMsg)


def displayMenu():
    while True:
        print("************* My Fast Food Hut **********")
        print("{:^40}".format("Menu:"))
        print("{:^40}".format("P)izza slices ($5.95)"))
        print("{:^32}".format("F)ries ($3.95)"))
        print("{:^34}".format("D)rinks ($2.75)"))
        print("{:^24}".format("T)otal"))
        print("{:^23}".format("E)xit"))
        selection = str(input("Enter Letter: "))
        if selection in ("p", "f", "d", "e"):
            return selection
        else:
            printError("Not a valid selection.")

def main():
    qtPizza = 0
    qtFries = 0
    qtDrinks = 0
    flag = True
    while flag:
        selection = displayMenu()
        if selection == "p":
            qtPizza += getQuantity("Pizza slices")
        elif selection == "f":
            qtFries += getQuantity("Fries")
        elif selection == "d":
            qtDrinks += getQuantity("Drinks")
        elif selection == "e":
            flag = False
        more_items = input("Any Thing Else? (Y/N): ")
        if more_items in ("N, n"):
            flag = false
        if more_items in ("Y, y"):
          flag = True
          selection = str(input("Enter Letter: "))
        if selection == "p":
            qtPizza += getQuantity("Pizza slices")
        elif selection == "f":
            qtFries += getQuantity("Fries")
        elif selection == "d":
            qtDrinks += getQuantity("Drinks")
        elif selection == "e":
            flag = False
        printBill(qtPizza, qtFries, qtDrinks, tax_rate)


if __name__ == '__main__':
    main()
