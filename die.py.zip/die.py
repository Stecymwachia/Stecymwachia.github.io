#!/usr/bin/env python3
#name: stecy mwachia
#date: 05.01.23
#project: die.py
import random

#prompt user for amount of die numbers you want the program to generate.

A_d_n= int(input("How many rolls do you want?:"))
if A_d_n <= 0:
        print("Number must be greater than o")
        A_d_n= int(input("How many rolls do you want?:"))

def generateNumber():
    return random.randint(1, 6)


for count in range(1,A_d_n+1):
    # Roll and print the dice
    # Returns a value from 1 to 42 inclusive
    print("%d %d" % (generateNumber(),random.randint(1, 42)))

    count = count + 1

#final
print("Those are your winning numbers!")






