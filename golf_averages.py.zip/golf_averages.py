#!/usr/bin/env python3
# name: stecy mwachia
# date: 05.10.23
# project: gold_Averages.py


# main() – contains the main logic and calls three functions.
def main():
    input_file = getFileName()
    output_file = "golf_average.txt"
    processGolfData(input_file, output_file)

# displayHeader() – called to display the column titles and line under them.
# This function should also write the header to the output file.
def displayHeader():
    print("{:<20}{:<10}".format("Golfer", "Score"))
    print("{:<20}{:<10}".format("-" * 6, "-" * 5))
    with open("golf_average.txt", "w") as file:
        file.write("Golfer,Score\n")

# getFileName()
def getFileName():
    # Collect the file names from user
    file_name = input("Enter file: ")
    return file_name

def openReadFile(input_name):
    with open(input_name, "r") as in_file:
        while True:
            # Read the next line, which should contain the name of the golfer.
            name = in_file.readline().strip()
            if not name:
                # End of file.
                break
            
            # Read the next four lines, which should contain the golfer's scores.
            scores = []
            for i in range(4):
                score_str = in_file.readline().strip()
                score = int(score_str)
                scores.append(score)
            
            # Calculate the average score.
            avg_score = sum(scores) / len(scores)
            
            # Call displayData to print the golfer's name and average score.
            displayData(name, avg_score)

# processGolfData
def processGolfData(input_file, output_file):
    with open(input_file, "r") as file_in, open(output_file, "w") as file_out:
        # Read golfer names and scores from input file
        golfers = []
        for line in file_in:
            name, *scores = line.split()
            scores = [int(score) for score in scores]
            avg_score = sum(scores) / len(scores)
            golfers.append((name, avg_score))

        # Calculate and print average scores for each golfer
        displayHeader()
        for golfer in golfers:
            name, avg_score = golfer
            displayData(name, avg_score)
            # Write golfer name and average score to output file
            file_out.write("{}, {:.2f}\n".format(name, avg_score))

# displayData
def displayData(name, average):
    # receives two parameters, the golfer's name and average,
    # then prints them as formatted output.
    formatted_data = "{:<20}{:<10.2f}".format(name, average)
    print(formatted_data)
    # Write the formatted data to the file
    with open("golf_average.txt", "a") as file:
        file.write(formatted_data + "\n")


if __name__ == "__main__":
    input_file = getFileName()
    openReadFile(input_file)
